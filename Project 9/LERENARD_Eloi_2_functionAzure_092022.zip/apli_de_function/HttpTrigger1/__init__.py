
import logging
import azure.functions as func

import requests

def main(req: func.HttpRequest) -> func.HttpResponse:
    userID = req.params.get('userID')

    url = "https://webappp9p.azurewebsites.net/api?userID="
    x = requests.post(url+userID)
    reco = x.text

    return func.HttpResponse(f"Hello, {reco}")
